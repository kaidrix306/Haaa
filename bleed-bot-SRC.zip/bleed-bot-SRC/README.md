Discord Bleed Bot SRC
https://bleed.bot/